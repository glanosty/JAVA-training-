package com.java.practice.literals;

public class TestOct {
	public static void main(String[] args) {
		int x = 09; //Literal 09 is out of range 
		System.out.println(x);
	}
}
