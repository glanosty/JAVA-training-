package com.java.practoice;

public class practice {
	public static void main(String[] args) {
		boolean b = true;
		b = b & false;
		System.out.println(b);
	}
			}
