package com.java.practoice;

public class CharProblem {
	public static void main(String[] args) {
		char a='A';
		char b= 1;
		char c= (char)(a+b);
		System.out.println(c);
		System.out.println((int)c);
	}
}

