package com.java.practice.literals;

public class TestUnderScrew {
	public static void main(String[] args) {
		int x= 1_00_00;
		System.out.println(x);
	}
}
